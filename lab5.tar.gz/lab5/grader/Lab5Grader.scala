object Lab5Grader {
  def main(args: Array[String]) {
    (new Lab5Grading).execute(stats = true)
  }
}
